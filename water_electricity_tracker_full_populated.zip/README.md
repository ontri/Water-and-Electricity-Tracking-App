# Water & Electricity Tracker App

## Setup Instructions

1. Install Node.js and MySQL
2. Run `npm install` in frontend directory
3. Start backend: `node server.js`
4. Run React app: `npm start`